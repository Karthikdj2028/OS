# Binning and smoothing in R
# Replace marks with your own numeric data

marks <- c(55, 60, 71, 63, 55, 65, 50, 55, 58, 59, 61, 63, 65, 67, 71, 72, 75)

# Equal-width binning into 3 bins
bins_equal_width <- cut(marks, breaks = 3)
table(bins_equal_width)
bins_equal_width

# Equal-frequency binning into 3 bins
k <- 3
probs <- seq(0, 1, length.out = k + 1)
breaks_quantiles <- quantile(marks, probs)
bins_equal_freq <- cut(marks, breaks = breaks_quantiles, include.lowest = TRUE)
table(bins_equal_freq)
bins_equal_freq

# Smoothing by bin mean (for equal-frequency bins)
smoothed_mean <- ave(marks, bins_equal_freq, FUN = mean)
smoothed_mean
