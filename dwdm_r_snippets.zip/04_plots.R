# Common plots in R

# Scatter plot example (mobiles vs money)
mobiles_sold <- c(4, 1, 5, 7, 10, 2, 50, 25, 90, 36)
money_earned <- c(12, 5, 13, 19, 31, 7, 153, 72, 275, 110)

plot(mobiles_sold, money_earned,
     xlab = "Mobiles sold",
     ylab = "Money earned",
     main = "Sales scatter plot")

# Histogram and boxplot example
marks <- c(55, 60, 71, 63, 55, 65, 50, 55, 58, 59, 61, 63, 65, 67, 71, 72, 75)

hist(marks, main = "Histogram of Marks")
boxplot(marks, main = "Boxplot of Marks")

# QQ plot (check normality)
qqnorm(marks)
qqline(marks)
