# Basic statistics example in R
# Replace x with your own numeric data vector

x <- c(13, 15, 16, 16, 19, 20, 20, 21)

# Mean, median, standard deviation
mean(x)
median(x)
sd(x)

# Quartiles and five-number summary
quantile(x)          # min, Q1, median, Q3, max
quantile(x, 0.25)    # Q1
quantile(x, 0.75)    # Q3

# Simple mode (can return more than one value)
tbl  <- table(x)
mode_values <- names(tbl)[tbl == max(tbl)]
mode_values
