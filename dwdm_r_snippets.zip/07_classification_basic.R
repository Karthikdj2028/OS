# Basic classification example in R
# Decision Tree and Naive Bayes on a small toy dataset

library(rpart)
library(e1071)

df <- data.frame(
  age    = factor(c("<=30","<=30",">40",">40")),
  income = factor(c("high","high","low","medium")),
  buys   = factor(c("no","no","yes","yes"))
)

set.seed(1)
idx   <- sample(1:nrow(df), 0.75 * nrow(df))
train <- df[idx, ]
test  <- df[-idx, ]

# Decision tree
dt_model   <- rpart(buys ~ ., data = train, method = "class")
dt_pred    <- predict(dt_model, test, type = "class")
dt_accuracy <- mean(dt_pred == test$buys)
dt_accuracy

# Naive Bayes
nb_model   <- naiveBayes(buys ~ ., data = train)
nb_pred    <- predict(nb_model, test)
nb_accuracy <- mean(nb_pred == test$buys)
nb_accuracy
