# K-means clustering in R
# Example using Salary and CreditScore

salary <- c(20, 22, 25, 40, 45, 60)
credit <- c(2, 3, 3, 5, 6, 8)

data <- data.frame(salary, credit)

set.seed(1)  # for reproducible results
km <- kmeans(data, centers = 3)  # choose number of clusters

# Cluster centers
km$centers

# Cluster assignment for each point
km$cluster

# Plot with clusters
plot(data, col = km$cluster,
     xlab = "Salary", ylab = "Credit Score")
points(km$centers, pch = 8, cex = 2)
