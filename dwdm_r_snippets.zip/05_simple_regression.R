# Simple linear regression in R
# Example using Age and BloodPressure (as in diabetes dataset)

# Make sure diabetes.csv is in your working directory
df <- read.csv("diabetes.csv")

# Simple regression: BloodPressure as a function of Age
model <- lm(BloodPressure ~ Age, data = df)

# View summary (coefficients, p-values, R-squared)
summary(model)

# Scatter plot with regression line
plot(df$Age, df$BloodPressure,
     xlab = "Age",
     ylab = "Blood Pressure")
abline(model, col = "red")
