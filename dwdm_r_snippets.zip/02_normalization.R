# Normalization examples in R
# Replace x with your own numeric data

x <- c(200, 300, 400, 600, 1000)

# Min–max normalization to [0, 1]
x_minmax <- (x - min(x)) / (max(x) - min(x))
x_minmax

# Z-score normalization (standardization)
x_z <- scale(x)   # uses built-in mean and sd
x_z

# Decimal scaling normalization
j <- nchar(as.character(max(abs(x))))
x_dec <- x / 10^j
x_dec

# Z-score for a single value x0 if mean and sd are given in the question
x0 <- 35
mu <- 40
sd_val <- 12.94
z_x0 <- (x0 - mu) / sd_val
z_x0
