# Association rules in R using arules package
# Install package if needed: install.packages("arules")

library(arules)

# Example transaction list
transactions_list <- list(
  c("M", "O", "N", "K", "E", "Y"),
  c("D", "O", "N", "K", "E", "Y"),
  c("M", "A", "K", "E"),
  c("M", "U", "C", "K", "Y"),
  c("C", "O", "O", "K", "I", "E")
)

tr <- as(transactions_list, "transactions")

# Generate association rules
rules <- apriori(tr,
                 parameter = list(supp = 0.4, conf = 0.8, minlen = 2))

# View rules
inspect(rules)
